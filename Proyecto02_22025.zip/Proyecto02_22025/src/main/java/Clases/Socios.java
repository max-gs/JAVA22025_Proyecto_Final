package Clases;

import java.sql.Date;

public class Socios 
{
	private int id_socios;
	private String nombre;
	private String apellido;
	private int dni;
	private String mail;
	private boolean estado;
	
		
	public Socios(int id_socios, String nombre, String apellido, int dni, String mail, boolean estado) {
		super();
		this.id_socios = id_socios;
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.mail = mail;
		this.estado = estado;
	}


	public Socios()
	{
		super();
	}


	
	public int getId_socios() {
		return id_socios;
	}


	public void setId_socios(int id_socios) {
		this.id_socios = id_socios;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public int getDni() {
		return dni;
	}


	public void setDni(int dni) {
		this.dni = dni;
	}


	public String getMail() {
		return mail;
	}


	public void setMail(String mail) {
		this.mail = mail;
	}


	public boolean isEstado() {
		return estado;
	}


	public void setEstado(boolean estado) {
		this.estado = estado;
	}

}

